<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_page extends CI_Controller {
	function __construct() {
        parent::__construct();
        
         $this->load->model('Dbs');
         if(!$this->session->userdata('logged_in')){
            redirect('Login');
         }
        
	}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$this->load->view('admin/dashboard');
	}
	public function slider()
	{
		$this->load->view('admin/slider');
	}
	public function add_slider()
	{

		// echo "<pre>";print_r($_POST);
		$postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('slider',$postData);
 $this->session->set_flashdata('msg','Record Added Successfully');
 redirect('Admin_page/slider');
	}

		public function edit_slider()
	{

		// echo "<pre>";print_r($_POST);exit();
		$postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
  $this->Dbs->edit('slider','id ='.$_POST['id'],$postData);
  $this->session->set_flashdata('msg','Record Updated Successfully');
 redirect('Admin_page/slider');
	}
	public function delete_slider()
	{


		 $this->Dbs->delete('slider','id ='.$this->uri->segment(3));
         $this->session->set_flashdata('msg1','Record Deleted Successfully');
 redirect('Admin_page/slider');
	}
	public function fetch_slider()
	{
		$query = $this->db->query('select * from slider where id='.$_POST['id']);

                                          $row= $query->result_array();
		// echo "<pre>";print_r($row);
		?>
		 <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="link" class="form-control" placeholder="Hyperlink" value="<?php  echo $row[0]['link'] ?>" />
                                        </div>
                            </div>
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="photo" class="form-control"  />
                                        </div>
                            </div>
                             <div class="form-group">
                                    <select class="form-control form-line show-tick" name="status">
                                       
                                        <option value="1"  <?php  if($row[0]['status']=="1")
                                        { 
                                        	echo "selected"; 
                                        } ?>>Active</option>
                                        <option value="0"  <?php  if($row[0]['status']=="0")
                                        { 
                                        	echo "selected";
                                        	 } ?>>De-Active</option>
                                        
                                    </select>
                                </div>

		<?php
		
	}


	public function brand()
	{
		$this->load->view('admin/brand');
	}
	public function add_brand()
	{

		// echo "<pre>";print_r($_POST);
		$postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('brand',$postData);
 $this->session->set_flashdata('msg','Record Added Successfully');
 redirect('Admin_page/brand');
	}

		public function edit_brand()
	{

		// echo "<pre>";print_r($_POST);exit();
		$postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
  $this->Dbs->edit('brand','id ='.$_POST['id'],$postData);
  $this->session->set_flashdata('msg','Record Updated Successfully');
 redirect('Admin_page/brand');
	}
	public function delete_brand()
	{
		

		 $this->Dbs->delete('brand','id ='.$this->uri->segment(3));
         $this->session->set_flashdata('msg1','Record Deleted Successfully');
 redirect('Admin_page/brand');
	}
	public function fetch_brand()
	{
		$query = $this->db->query('select * from brand where id='.$_POST['id']);

                                          $row= $query->result_array();
		// echo "<pre>";print_r($row);
		?>
		 <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="link" class="form-control" placeholder="Hyperlink" value="<?php  echo $row[0]['link'] ?>" />
                                        </div>
                            </div>
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="photo" class="form-control"  />
                                        </div>
                            </div>
                             <div class="form-group">
                                    <select class="form-control form-line show-tick" name="status">
                                       
                                        <option value="1"  <?php  if($row[0]['status']=="1")
                                        { 
                                        	echo "selected"; 
                                        } ?>>Active</option>
                                        <option value="0"  <?php  if($row[0]['status']=="0")
                                        { 
                                        	echo "selected";
                                        	 } ?>>De-Active</option>
                                        
                                    </select>
                                </div>

		<?php
		
	}

// services start
	public function services()
	{
		$this->load->view('admin/services');
	}
	public function add_services()
	{

		// echo "<pre>";print_r($_POST);
		$postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('services',$postData);
 $this->session->set_flashdata('msg','Record Added Successfully');
 redirect('Admin_page/services');
	}

		public function edit_services()
	{

		// echo "<pre>";print_r($_POST);exit();
		$postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
        $this->session->set_flashdata('msg','Record Updated Successfully');
  $this->Dbs->edit('services','id ='.$_POST['id'],$postData);
 redirect('Admin_page/services');
	}
	public function delete_services()
	{
		

		 $this->Dbs->delete('services','id ='.$this->uri->segment(3));
         $this->session->set_flashdata('msg1','Record Deleted Successfully');
 redirect('Admin_page/services');
	}
	public function fetch_services()
	{
		$query = $this->db->query('select * from services where id='.$_POST['id']);

                                          $row= $query->result_array();
		// echo "<pre>";print_r($row);
		?>
		 <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="title" class="form-control" placeholder="Title" value="<?php  echo $row[0]['title'] ?>" />
                                        </div>
                            </div>
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="photo" class="form-control"  />
                                        </div>
                            </div>
                             <div class="form-group">
                                    <select class="form-control form-line show-tick" name="status">
                                       
                                        <option value="1"  <?php  if($row[0]['status']=="1")
                                        { 
                                        	echo "selected"; 
                                        } ?>>Active</option>
                                        <option value="0"  <?php  if($row[0]['status']=="0")
                                        { 
                                        	echo "selected";
                                        	 } ?>>De-Active</option>
                                        
                                    </select>
                                </div>

                            <div class="form-group">
                                        <div class="form-line">
                                           
                                            <textarea name="des" class="form-control" placeholder="Description" required="" ><?php  echo $row[0]['des'] ?></textarea>
                                        </div>
                            </div>  
		<?php
		
	}

// services end
	// Projects start
	public function Projects()
	{
		$this->load->view('admin/Projects');
	}
	public function add_Projects()
	{

		// echo "<pre>";print_r($_POST);
		$postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('Projects',$postData);
 $this->session->set_flashdata('msg','Record Added Successfully');
 redirect('Admin_page/Projects');
	}

		public function edit_Projects()
	{

		// echo "<pre>";print_r($_POST);exit();
		$postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;

  $this->Dbs->edit('Projects','id ='.$_POST['id'],$postData);
  $this->session->set_flashdata('msg','Record Updated Successfully');
 redirect('Admin_page/Projects');
	}
	public function delete_Projects()
	{
		

		 $this->Dbs->delete('Projects','id ='.$this->uri->segment(3));
         $this->session->set_flashdata('msg1','Record Deleted Successfully');
 redirect('Admin_page/Projects');
	}
	public function fetch_Projects()
	{
		$query = $this->db->query('select * from Projects where id='.$_POST['id']);

                                          $row= $query->result_array();
		// echo "<pre>";print_r($row);
		?>
        <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="title" class="form-control" placeholder="title" required="" value="<?php  echo $row[0]['title'] ?>" />
                                        </div>
                            </div>
		 <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="link" class="form-control" placeholder="Hyperlink" value="<?php  echo $row[0]['link'] ?>" />
                                        </div>
                            </div>
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="photo" class="form-control"  />
                                        </div>
                            </div>
                             <div class="form-group">
                                    <select class="form-control form-line show-tick" name="status">
                                       
                                        <option value="1"  <?php  if($row[0]['status']=="1")
                                        { 
                                        	echo "selected"; 
                                        } ?>>Active</option>
                                        <option value="0"  <?php  if($row[0]['status']=="0")
                                        { 
                                        	echo "selected";
                                        	 } ?>>De-Active</option>
                                        
                                    </select>
                                </div>

                            <div class="form-group">
                                        <div class="form-line">
                                           
                                            <textarea name="des" class="form-control" placeholder="Description" required="" ><?php  echo $row[0]['des'] ?></textarea>
                                        </div>
                            </div>  
		<?php
		
	}
	// Projects end

   // job_post start



	public function job_post()
	{
		$this->load->view('admin/job_post');
	}
	public function add_job_post()
	{

		// echo "<pre>";print_r($_POST);
		$postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('job_post',$postData);
 $this->session->set_flashdata('msg','Record Added Successfully');
 redirect('Admin_page/job_post');
	}

		public function edit_job_post()
	{

		// echo "<pre>";print_r($_POST);exit();
		$postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
        $this->session->set_flashdata('msg','Record Updated Successfully');
  $this->Dbs->edit('job_post','id ='.$_POST['id'],$postData);
 redirect('Admin_page/job_post');
	}
	public function delete_job_post()
	{
		

		 $this->Dbs->delete('job_post','id ='.$this->uri->segment(3));
         $this->session->set_flashdata('msg1','Record Deleted Successfully');
 redirect('Admin_page/job_post');
	}
	public function fetch_job_post()
	{
		$query = $this->db->query('select * from job_post where id='.$_POST['id']);

                                          $row= $query->result_array();
		// echo "<pre>";print_r($row);
		?>
		<div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="title" class="form-control" placeholder="title" value="<?php  echo $row[0]['title'] ?>" required="" />
                                        </div>
                            </div>
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="experiance" class="form-control" placeholder="experiance" value="<?php  echo $row[0]['experiance'] ?>" required="" />
                                        </div>
                            </div>
                            <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="location" class="form-control" placeholder="location" value="<?php  echo $row[0]['location'] ?>" required="" />
                                        </div>
                            </div>
                            <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="skill" class="form-control" placeholder="skill" value="<?php  echo $row[0]['skill'] ?>" required="" />
                                        </div>
                            </div>
                            <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="sallary" class="form-control" placeholder="sallary" required="" value="<?php  echo $row[0]['sallary'] ?>" />
                                        </div>
                            </div>
                             <div class="form-group">
                                    <select class="form-control form-line show-tick" name="status">
                                       
                                        <option value="1"  <?php  if($row[0]['status']=="1")
                                        { 
                                        	echo "selected"; 
                                        } ?>>Active</option>
                                        <option value="0"  <?php  if($row[0]['status']=="0")
                                        { 
                                        	echo "selected";
                                        	 } ?>>De-Active</option>
                                        
                                    </select>
                                </div>

                             
		<?php
		
	}














    public function about_us()
    {
        $this->load->view('admin/about_us');
    }
    public function add_about_us()
    {

        // echo "<pre>";print_r($_POST);
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('about_us',$postData);
  $this->session->set_flashdata('msg','Record Added Successfully');
 redirect('Admin_page/about_us');
    }

        public function edit_about_us()
    {

        // echo "<pre>";print_r($_POST);exit();
        $postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
  $this->Dbs->edit('about_us','id ='.$_POST['id'],$postData);
  $this->session->set_flashdata('msg','Record Updated Successfully');
 redirect('Admin_page/about_us');
    }
    public function delete_about_us()
    {
        

         $this->Dbs->delete('about_us','id ='.$this->uri->segment(3));
          $this->session->set_flashdata('msg1','Record Deleted Successfully');
 redirect('Admin_page/about_us');
    }
    public function fetch_about_us()
    {
        $query = $this->db->query('select * from about_us where id='.$_POST['id']);

                                          $row= $query->result_array();
        // echo "<pre>";print_r($row);
        ?>
       
      
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="photo" class="form-control"  />
                                        </div>
                            </div>
                           

                            <div class="form-group">
                                        <div class="form-line">
                                           
                                            <textarea name="des" id="tinymce" class="ckeditor form-control" placeholder="Description" required="" >
                                                <?php  echo $row[0]['des'] ?>
                                                    
                                            </textarea>
                                        </div>
                            </div>  
        <?php
        
    }


    public function contact_us()
    {
        $this->load->view('admin/contact_us');
    }
    public function apply_post()
    {
        $this->load->view('admin/apply_post');
    }


public function logo()
    {
        $this->load->view('admin/logo');
    }
    public function add_logo()
    {

        // echo "<pre>";print_r($_POST);
        $postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('logo',$postData);
  $this->session->set_flashdata('msg','Record Added Successfully');
 redirect('Admin_page/logo');
    }

        public function edit_logo()
    {

        // echo "<pre>";print_r($_POST);exit();
        $postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
  $this->Dbs->edit('logo','id ='.$_POST['id'],$postData);
  $this->session->set_flashdata('msg','Record Updated Successfully');
 redirect('Admin_page/logo');
    }
    public function delete_logo()
    {
        

         $this->Dbs->delete('logo','id ='.$this->uri->segment(3));
          $this->session->set_flashdata('msg1','Record Deleted Successfully');
 redirect('Admin_page/logo');
    }
    public function fetch_logo()
    {
        $query = $this->db->query('select * from logo where id='.$_POST['id']);

                                          $row= $query->result_array();
        // echo "<pre>";print_r($row);
        ?>
       
      
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="photo" class="form-control"  />
                                        </div>
                            </div>
                           

                            <div class="form-group">
                                        
                                           <img src="<?php echo base_url('uploads/'.$row[0]['photo']); ?>" style="height: 50px;width: 50px">
                                      
                            </div>  
        <?php
        
    }

























}
