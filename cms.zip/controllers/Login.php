<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	function __construct() {
        parent::__construct();
        
         $this->load->model('Dbs');
        
	}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$this->load->view('admin/login');
	}
	public function sign_in()
    {

        $login = $this->Dbs->fetch('admin_login',array('username'=>$_POST['username'],'password'=>md5($_POST['password'])));
        if(isset($login) && !empty($login)){

            $newdata = array(
                'id'=>$login[0]['id'],
                
                'username'=>$login[0]['username'],
                
                'logged_in'=>TRUE
            );

            $this->session->set_userdata($newdata);
             $this->session->set_flashdata('msg','Welcome To Admin Dashboard');
            redirect('Admin_page');
        }
        else{
           $this->session->set_flashdata('msg','login failed');
            redirect('Login'); 
        }
       
    }
    function logout(){
    	 $this->session->set_flashdata('msg','Successfully Logout');
        $this->session->set_userdata(array('logged_in' => FALSE));
        $this->session->sess_destroy();

        redirect('Login'); 

    }
	
}
