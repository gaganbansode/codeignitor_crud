<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Services extends CI_Controller {
	function __construct() {
        parent::__construct();
        
         $this->load->model('Dbs');
        
	}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	public function index()
	{
		$this->load->view('admin/dashboard');
	}
	public function slider()
	{
		$this->load->view('admin/slider');
	}
	public function add_slider()
	{

		// echo "<pre>";print_r($_POST);
		$postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('slider',$postData);
 redirect('Services/slider');
	}

		public function edit_slider()
	{

		// echo "<pre>";print_r($_POST);exit();
		$postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
  $this->Dbs->edit('slider','id ='.$_POST['id'],$postData);
 redirect('Services/slider');
	}
	public function delete_slider()
	{


		 $this->Dbs->delete('slider','id ='.$this->uri->segment(3));
 redirect('Services/slider');
	}
	public function fetch_slider()
	{
		$query = $this->db->query('select * from slider where id='.$_POST['id']);

                                          $row= $query->result_array();
		// echo "<pre>";print_r($row);
		?>
		 <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="link" class="form-control" placeholder="Hyperlink" value="<?php  echo $row[0]['link'] ?>" />
                                        </div>
                            </div>
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="photo" class="form-control"  />
                                        </div>
                            </div>
                             <div class="form-group">
                                    <select class="form-control form-line show-tick" name="status">
                                       
                                        <option value="1"  <?php  if($row[0]['status']=="1")
                                        { 
                                        	echo "selected"; 
                                        } ?>>Active</option>
                                        <option value="0"  <?php  if($row[0]['status']=="0")
                                        { 
                                        	echo "selected";
                                        	 } ?>>De-Active</option>
                                        
                                    </select>
                                </div>

		<?php
		
	}


	public function brand()
	{
		$this->load->view('admin/brand');
	}
	public function add_brand()
	{

		// echo "<pre>";print_r($_POST);
		$postData = $_POST;
        $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
 $sqlu=$this->Dbs->add('brand',$postData);
 redirect('Services/brand');
	}

		public function edit_brand()
	{

		// echo "<pre>";print_r($_POST);exit();
		$postData = $_POST;
        // $ID = $this->input->get_post('ID');

        if(!empty($_FILES['photo'])){
            $uploaddir = 'uploads/';
            $oxiinc=rand().".png";
            $uploadfile = $uploaddir . $oxiinc;

            if (move_uploaded_file($_FILES['photo']['tmp_name'], $uploadfile)) {
             
              $postData['photo'] = $oxiinc;
            }
        }
// echo '<pre>'; print_r($postData); exit;
  $this->Dbs->edit('brand','id ='.$_POST['id'],$postData);
 redirect('Services/brand');
	}
	public function delete_brand()
	{
		

		 $this->Dbs->delete('brand','id ='.$this->uri->segment(3));
 redirect('Services/brand');
	}
	public function fetch_brand()
	{
		$query = $this->db->query('select * from brand where id='.$_POST['id']);

                                          $row= $query->result_array();
		// echo "<pre>";print_r($row);
		?>
		 <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="link" class="form-control" placeholder="Hyperlink" value="<?php  echo $row[0]['link'] ?>" />
                                        </div>
                            </div>
                              <div class="form-group">
                                        <div class="form-line">
                                            <input type="file" name="photo" class="form-control"  />
                                        </div>
                            </div>
                             <div class="form-group">
                                    <select class="form-control form-line show-tick" name="status">
                                       
                                        <option value="1"  <?php  if($row[0]['status']=="1")
                                        { 
                                        	echo "selected"; 
                                        } ?>>Active</option>
                                        <option value="0"  <?php  if($row[0]['status']=="0")
                                        { 
                                        	echo "selected";
                                        	 } ?>>De-Active</option>
                                        
                                    </select>
                                </div>

		<?php
		
	}
}
