 <section class="bg-gray-100 section-xs text-center" style="background-color: #3C468C;">
        <div class="container">
          <p class="rights"><span>&copy;&nbsp;</span><span class="copyright-year"></span>. All Rights Reserved. Design by <a href="<?php echo base_url(); ?>">oxiincgroup.com</a></p>
        </div>
      </section>