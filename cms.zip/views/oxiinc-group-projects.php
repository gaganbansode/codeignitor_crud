
   <?php include_once('head.php') ?>
   
  <body style="background-color: #FFDBCA">
   
    <div class="preloader">
      <div class="preloader-body"> 
        <div class="cssload-jumping"><span></span><span></span><span></span><span></span><span></span></div>
      </div>
    </div>
    <div class="page">
      <!-- Page Header-->
    <?php include_once('header.php') ?>
      <section class="section-page-title" style="background-image: url(<?php echo base_url('files/'); ?>images/page-title-3-1920x305.jpg); background-size: cover;">
        <div class="container">
     
        </div>
      </section>
      
      <section class="section section-lg bg-default">
        <div class="container">
          <div class="row row-50 align-items-lg-center justify-content-xl-between">
           <?php  foreach ($projects as $key => $value) {
              # code...
            ?>
           <div class="col-6">
                    <div class="box-image-item avinash" data-parallax-scroll="{&quot;y&quot;: 0, &quot;x&quot;: -20,  &quot;smoothness&quot;: 30 }">
                      <a href="<?php  echo $value['link']; ?>" target="blank">
                      <img src="<?php echo base_url('uploads/'.$value['photo']); ?>" alt="" style="height: 300px;width: 100%" /></a>

                       <div class="overlay">
                        <div class="text"><?php  echo $value['title']; ?></div>
                        
                        </button>
                      </div>
                    </div>
                  </div>
                 <?php  } ?>  
          </div>
        </div>
      </section>
    
   
    
       <?php include_once('footer.php') ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="<?php echo base_url('files/'); ?>js/core.min.js"></script>
    <script src="<?php echo base_url('files/'); ?>js/script.js"></script>
  </body>
</html>