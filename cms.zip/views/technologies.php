
   <?php include_once('head.php') ?>
  
  <body>
   
    <div class="preloader">
      <div class="preloader-body"> 
        <div class="cssload-jumping"><span></span><span></span><span></span><span></span><span></span></div>
      </div>
    </div>
    <div class="page">
      <!-- Page Header-->
    <?php include_once('header.php') ?>

   <section class="section-page-title" style="background-image: url(<?php echo base_url('files/'); ?>images/page-title-3-1920x305.jpg); background-size: cover;">
        <div class="container">
       <!--    <h1 class="page-title">About</h1> -->
        </div>
      </section>
  <section class="section section-lg bg-default">
  <div class="container">
   <!--  <center><h1>TECHNOLOGIES</h1></center><br> -->
    <div class="row row-50 align-items-lg-center justify-content-xl-between">
        <div class="col-sm-6 col-md-4" style="padding:10px;    box-shadow: gainsboro 1px 0px 6px 0px;">
            <figure style="text-align: center; padding-bottom: 15px;">
              <img src="<?php echo base_url('files/'); ?>images/logot/PHP.png" class="img-rounded  " style=" margin-bottom: 15px;">
              
              <p class="pc" style="font-size: 25px;"><span style="font-size: 40px;">C</span>ore MVC PHP</p>
              <p style="padding:10px">PHP has remained one of the most versatile and pragmatic web development languages in the world today. Its range of functionalities, amazing array of add-ins to extend functionalities, its open source nature and tremendous online community support has made PHP a perennial favorite amongst newbies as well as established development agencies worldwide.<br><br></p>
            </figure>
         </div>   
          <div class="col-sm-6 col-md-4" style="padding:10px">
            <figure style="text-align: center; padding-bottom: 15px;">
              <img src="<?php echo base_url('files/'); ?>images/logot/OPENCHART2.png" class="img-rounded  " style=" margin-bottom: 15px;">
              
              <p class="pc" style="font-size: 25px;"><span style="font-size: 40px;">O</span>pencart</p>
              <p style="padding:10px">OpenCart is  open source e-commerce platform for online merchants. OpenCart provides a professional and reliable foundation from which to build a successful online store. This foundation appeals to a wide variety of users; ranging from seasoned web developers looking for a user-friendly interface to use, to shop owners just launching their business online for the first time.</p>
            </figure>
          </div>
          <div class="col-sm-6 col-md-4" style="padding:10px;box-shadow: gainsboro 1px 0px 6px 0px;">
            <figure style="text-align: center; padding-bottom: 15px;">
              <img src="<?php echo base_url('files/'); ?>images/logot/MAGENTO.png" class="img-rounded  " style=" margin-bottom: 15px;">
              
              <p class="pc" style="font-size: 25px;"><span style="font-size: 40px;">M</span>angeto</p>
              <p style="padding:10px">Outperform Your Enterprise Website Needs.Magento is a feature-rich open-source platform known for its flexible features and functionalities typically suitable for online stores and eCommerce portals.<br><br><br><br><br></p>
            </figure>
          </div>   
      </div>
    </div>  <br>

    <div class="container">
    <div class="row jack">
        <div class="col-sm-6 col-md-4" style="padding:10px;box-shadow: gainsboro 1px 0px 6px 0px;">
            <figure style="text-align: center; padding-bottom: 15px; margin-top: 5px;">
              <img src="<?php echo base_url('files/'); ?>images/logot/WORD-PRESS.png" class="img-rounded  " style=" margin-bottom: 15px;">
              
              <p class="pc" style="font-size: 25px;"><span style="font-size: 40px;">W</span>ordPress </p>
              <p style="padding:10px">"WordPress is a factory that makes webpages" is a core analogy designed to clarify what WordPress is and does. It stores your content that allows you to create & publish webpages only requiring a domain and a hosting site to work.</p>
            </figure>
         </div>   
          <div class="col-sm-6 col-md-4" style="padding:10px">
            <figure style="text-align: center; padding-bottom: 15px; margin-top: 5px;">
              <img src="<?php echo base_url('files/'); ?>images/logot/CODINGNITER.png" class="img-rounded  " style=" margin-bottom: 15px;">
              
              <p class="pc" style="font-size: 25px;"><span style="font-size: 40px;">C</span>odeIgniter</p>
              <p style="padding:10px">CodeIgniter is an open-source software rapid development web framework, for use in building dynamic web sites with PHP.</p>
            </figure>
          </div>
           <div class="col-sm-6 col-md-4" style="padding:10px;box-shadow: gainsboro 1px 0px 6px 0px;">
            <figure style="text-align: center; padding-bottom: 15px; margin-top: 5px;">
              <img src="<?php echo base_url('files/'); ?>images/logot/LARAWELL.png" class="img-rounded  " style=" margin-bottom: 15px;">
              
              <p class="pc" style="font-size: 25px;"><span style="font-size: 40px;">L</span>aravel</p>
              <p style="padding:10px">Laravel is a open-source PHP web framework, created by Taylor Otwell and intended for the development of web applications following the model–view–controller(MVC) architectural pattern.</p>
            </figure>
          </div>
         
      </div>
    </div> <br>

    <div class="container">
    <div class="row jack">
        <div class="col-sm-6 col-md-4" style="padding:10px;box-shadow: gainsboro 1px 0px 6px 0px;">
            <figure style="text-align: center; padding-bottom: 15px; margin-top: 5px;">
              <img src="<?php echo base_url('files/'); ?>images/logot/SYMFONY.png" class="img-rounded  " style=" margin-bottom: 15px;">
              
              <p class="pc" style="font-size: 25px;"><span style="font-size: 40px;">S</span>ymfony </p>
              <p style="padding:10px">Symfony is a PHP web application framework and a set of reusable PHP components/libraries.</p>
            </figure>
         </div>   
          <div class="col-sm-6 col-md-4" style="padding:10px">
            <figure style="text-align: center; padding-bottom: 15px; margin-top: 5px;">
              <img src="<?php echo base_url('files/'); ?>images/logot/YII.png" class="img-rounded  " style=" margin-bottom: 15px;">
              
              <p class="pc" style="font-size: 25px;"><span style="font-size: 40px;">Y</span>ii</p>
              <p style="padding:10px">Yii is an open source, object-oriented, component-based MVC PHP web application framework. Yii is pronounced as "Yee" or  and in Chinese it means "simple and evolutionary" and it can be an acronym for "Yes It Is!".</p>
            </figure>
          </div>
           
    </div> 
 
       
    
  </section>
    
   
    
       <?php include_once('footer.php') ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="<?php echo base_url('files/'); ?>js/core.min.js"></script>
    <script src="<?php echo base_url('files/'); ?>js/script.js"></script>
  </body>
</html>