
     <?php include_once('head.php') ?>
 
  <body>
    <div class="ie-panel"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="<?php echo base_url('files/'); ?>images/ie8-panel/warning_bar_0000_us.jpg" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <div class="preloader">
      <div class="preloader-body"> 
        <div class="cssload-jumping"><span></span><span></span><span></span><span></span><span></span></div>
      </div>
    </div>
    <div class="page">
      <!-- Page Header-->
     <?php include_once('header.php') ?>

      <section class="section-page-title" style="background-image: url(<?php echo base_url('files/'); ?>images/page-title-3-1920x305.jpg); background-size: cover;">
        <div class="container">
       <!--    <h1 class="page-title">Contacts</h1> -->
        </div>
      </section>
   <!--    <section class="breadcrumbs-custom">
        <div class="container">
          <ul class="breadcrumbs-custom-path">
            <li><a href="index.php">Home</a></li>
            <li class="active">Contacts</li>
          </ul>
        </div>
      </section> -->
      <!-- Mailform-->
      <section class="section section-md">
        <div class="container">
          <div class="row row-50">
            <div class="col-lg-8">
              <h2>Contact us</h2>
              <div class="divider-lg"></div>
             
              <p>You can contact us any way that is convenient for you. We are available via Phones or email. </p>
              <!-- RD Mailform-->
              <form class="rd-mailform text-left rd-form"  id="myForm" action="" method="POST">
                <div class="row row-30">
                  <div class="col-sm-6">
                    <div class="form-wrap">
                      <label class="form-label" for="contact-name">First name</label>
                      <input class="form-input" id="contact-name" type="text" name="name" data-constraints="@Required">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-wrap">
                      <label class="form-label" for="contact-sec-name">Last name</label>
                      <input class="form-input" id="contact-sec-name" type="text" name="last_name" data-constraints="@Required">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-wrap">
                      <label class="form-label" for="contact-phone">Phone</label>
                      <input class="form-input" id="contact-phone" type="text" name="phone" data-constraints="@Numeric @Required">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-wrap">
                      <label class="form-label" for="contact-email">E-Mail</label>
                      <input class="form-input" id="contact-email" type="email" name="email" data-constraints="@Email @Required">
                    </div>
                  </div>
                  <div class="col-12">
                    <div class="form-wrap">
                      <label class="form-label" for="contact-message">Message</label>
                      <textarea class="form-input" id="contact-message" name="message" data-constraints="@Required"></textarea>
                    </div>
                  </div>
                </div>
                   <?php if($this->session->flashdata('msg')) {?>
              

                
                           <p style="color: green">     <?php echo $this->session->flashdata('msg');?></p> 
                           
                <?php }?>
                <div class="form-button group-sm text-left">
                  <button class="button button-primary" id="button" type="button">Send message</button>
                </div>
              </form>
            </div>
            <div class="col-lg-4">
              <ul class="contact-list">
                <li> 
                  <p class="contact-list-title">Address</p>
                  <div class="contact-list-content"><span class="icon mdi mdi-map-marker icon-primary"></span><a href="#">EROCKETMALL ONLINE ASIA LIMITED <br>
CIN - U74999MH2014PLC257236 <br>
D-414, Floral Deck Plaza, MIDC, Seepz, <br>
23rd Road, Andheri(E), Mumbai - 400093. </a></div>
                </li>
                <li>
                  <p class="contact-list-title">Phones</p>
                  <div class="contact-list-content"><span class="icon mdi mdi-phone icon-primary"></span><a href="tel:022-45104510">+022-45104510</a><span></div>
                </li>
                <li>
                  <p class="contact-list-title">E-mail</p>
                  <div class="contact-list-content"><span class="icon mdi mdi-email-outline icon-primary"></span><a href="mailto:info@oxiinc.in"> For general queries -: info@oxiinc.in</a></div>
                   <div class="contact-list-content"><span class="icon mdi mdi-email-outline icon-primary"></span><a href="mailto:sales@oxiinc.in"> For For sales -: sales@oxiinc.in</a></div>
                    <div class="contact-list-content"><span class="icon mdi mdi-email-outline icon-primary"></span><a href="mailto:help@oxiinc.in"> For For Support -: help@oxiinc.in</a></div>



                </li>
                <li>
                  <p class="contact-list-title">Opening Hours</p>
                  <div class="contact-list-content"><span class="icon mdi mdi-clock icon-primary"></span>
                    <ul class="list-xs">
                      <li>Mon-Saturday: 10 am – 7 pm</li>
                  
                      <li>Sunday: Closed</li>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
   
     
      <?php include_once('footer.php') ?>
    </div>
   
    <div class="snackbars" id="form-output-global"></div>
    <script src="<?php echo base_url('files/'); ?>js/core.min.js"></script>
    <script src="<?php echo base_url('files/'); ?>js/script.js"></script>
    <script type="text/javascript">
      $(document).ready(function (argument) {
        $("#button").click(function () {
          // body...
    $('#contact-name').val()
         $.ajax({

    url: "<?php echo base_url('home/Contact_us_msg'); ?>",

    type: "POST",

    data:"name=" + $('#contact-name').val() +"&last_name=" + $('#contact-sec-name').val() + "&phone=" + $('#contact-phone').val() +"&email=" + $('#contact-email').val()+"&message=" + $('#contact-message').val(),

    dataType:"text",

    success: function(data){

     
location.reload(true);
    }



    })
        });
      });
    </script>
  </body>
</html>