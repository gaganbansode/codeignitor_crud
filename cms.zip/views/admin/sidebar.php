<section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="<?php echo base_url('admin'); ?>/images/user.png" width="48" height="48" alt="User" />
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Gagan Bansode</div>
                    <div class="email">Gagan@oxiinc.in</div>
                    <div class="btn-group user-helper-dropdown">
                        <i class="material-icons" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">keyboard_arrow_down</i>
                        <ul class="dropdown-menu pull-right">
                            
                            <li><a href="<?php echo base_url('Login/logout');  ?>"><i class="material-icons">input</i>Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>
                    <li class="active">
                        <a href="<?php echo base_url('Admin_page');  ?>">
                            <i class="material-icons">home</i>
                            <span>Home</span>
                        </a>
                    </li>
                          <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">camera_enhance</i>
                            <span>website Logo</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url('Admin_page/logo');  ?>" >
                                    <span>website Logo</span>
                                </a>
                             
                            </li>

                           
                </ul>
            </li>
                       <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">event</i>
                            <span>About Us</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url('Admin_page/about_us');  ?>" >
                                    <span>About Us</span>
                                </a>
                             
                            </li>

                           
                </ul>
            </li>
              <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">contact_mail</i>
                            <span>Contact Us</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url('Admin_page/Contact_us');  ?>" >
                                    <span>Contact Us</span>
                                </a>
                             
                            </li>

                           
                </ul>
            </li>
                   
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">insert_photo</i>
                            <span>Banner's</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url('Admin_page/slider');  ?>" >
                                    <span>Banner's</span>
                                </a>
                             
                            </li>

                           
                </ul>
            </li>
            <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">folder</i>
                            <span>Brand's</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url('Admin_page/brand');  ?>" >
                                    <span>Brand's</span>
                                </a>
                             
                            </li>

                           
                </ul>
            </li>
            <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">extension</i>
                            <span>Services</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url('Admin_page/Services');  ?>" >
                                    <span>Services</span>
                                </a>
                             
                            </li>

                           
                </ul>
            </li>

             <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">shopping_cart</i>
                            <span>Our Projects</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url('Admin_page/Projects');  ?>" >
                                    <span>Our Projects</span>
                                </a>
                             
                            </li>

                           
                </ul>
            </li>
             <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">work</i>
                            <span>Job Post</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="<?php echo base_url('Admin_page/job_post');  ?>" >
                                    <span>Job Post</span>
                                </a>
                             
                            </li>

                           
                </ul>
            </li>
            <br>
            <br>
            <br>
            </div>

            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2016 - 2017 <a href="javascript:void(0);">Oxiinc Group</a>.
                </div>
                <div class="version">
                   
                </div>
            </div>
            <!-- #Footer -->
        </aside>
       
    </section>