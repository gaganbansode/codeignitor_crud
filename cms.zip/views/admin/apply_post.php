<?php  include 'header.php'; ?>
<?php  include 'sidebar.php'; ?>
<section class="content">
        <div class="container-fluid">
            <div class="block-header">
              
            </div>
              <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               Who applied for post
                            </h2>
                            <ul class="header-dropdown m-r--5">
                               
                            </ul>
                        </div>
                        <?php if($this->session->flashdata('msg')) {?>
              

                <div class="alert bg-green alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                 <?php echo $this->session->flashdata('msg');?>
                            </div>
                <?php }?>
                <?php if($this->session->flashdata('msg1')) {?>
              

                <div class="alert bg-pink alert-dismissible" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                 <?php echo $this->session->flashdata('msg1');?>
                            </div>
                <?php }?>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>Sr.no</th>
                                            <th>Name</th>
                                            
                                            <th>Last name</th>
                                            <th>Phone</th>
                                            <th>Email</th>
                                             <th>Resume</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>Sr.no</th>
                                            <th>Name</th>
                                            
                                            <th>Last name</th>
                                            <th>Phone</th>
                                            <th>Email</th>
                                             <th>Resume</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php 
                                           
        $query = $this->db->query('select * from apply_post where post_id='.$this->uri->segment(3).' order by id desc');

                                          $row= $query->result_array();
                                          $i=1;
                                          foreach ($row as $key => $value) {
                                              # code...
                                         

                                         ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $value['name']; ?></td>
                                            <td><?php echo $value['lname']; ?></td>
                                            <td><?php echo $value['mobile']; ?></td>
                                            <td><?php echo $value['email']; ?></td>
                                           
                                            <td><button type="button" class="btn btn-info waves-effect" data-toggle="modal" data-target="#defaultModal<?php echo $value['id']; ?>"><i class="material-icons">mode_edit</i></button></td>
                                           
                                        </tr>

<div class="modal fade" id="defaultModal<?php echo $value['id']; ?>" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="defaultModalLabel">Resume</h4>
                        </div>
                        <div class="modal-body">
                            <embed src="<?php echo base_url('uploads/'.$value['photo']); ?>"></embed>
                          
                        <div class="modal-footer">
                           
                            <button type="button" class="btn btn-title waves-effect" data-dismiss="modal">CLOSE</button>
                        </div>
                        
                    </div>
                </div>
            </div>

                                        <?php $i++; } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

            


    <?php  include 'footer.php'; ?>