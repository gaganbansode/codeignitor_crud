
   <?php include_once('head.php') ?>
   
 
   
    <div class="preloader">
      <div class="preloader-body"> 
        <div class="cssload-jumping"><span></span><span></span><span></span><span></span><span></span></div>
      </div>
    </div>
    <div class="page">
      <!-- Page Header-->
    <?php include_once('header.php') ?>
      <section class="section-page-title" style="background-image: url(<?php echo base_url('files/'); ?>images/page-title-3-1920x305.jpg); background-size: cover;">
        <div class="container">
          <h1 class="page-title">About</h1>
        </div>
      </section>
      
      <section class="section section-lg bg-default">
        <div class="container">
          <div class="row row-50 align-items-lg-center justify-content-xl-between">
            <div class="col-lg-6">
              <div class="block-xs">
                <h2>About Us</h2>
                <div class="divider-lg"></div>
                <p class="big text-gray-800"  style="text-align: justify;"><?php print_r($about_us[0]['des']);?></p>
              </div>
            
            </div>
            <div class="col-lg-6">
              <div class="box-images box-images-variant-3">
                <div class="box-images-item" data-parallax-scroll="{&quot;y&quot;: -20,   &quot;smoothness&quot;: 30 }"><img src="<?php echo base_url('uploads/'.$about_us[0]['photo']); ?>" alt="" width="470" height="282"/>
                </div>
                <div class="box-images-item box-images-without-border" data-parallax-scroll="{&quot;y&quot;: 40,  &quot;smoothness&quot;: 30 }"><img src="<?php echo base_url('uploads/'.$about_us[0]['photo']); ?>" alt="" width="470" height="282"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    
   
    
      < <?php include_once('footer.php') ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="<?php echo base_url('files/'); ?>js/core.min.js"></script>
    <script src="<?php echo base_url('files/'); ?>js/script.js"></script>
  </body>
</html>