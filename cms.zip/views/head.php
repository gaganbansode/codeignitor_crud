    
<!-- Page Title--><!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <title>oxiinc</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="<?php echo base_url('files/'); ?>images/logo.png" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('files/'); ?>css/css1.css">
    <link rel="stylesheet" href="<?php echo base_url('files/'); ?>css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url('files/'); ?>css/fonts.css">
     <link rel="stylesheet" href="<?php echo base_url('files/'); ?>css/avinash.css">
    <link rel="stylesheet" href="<?php echo base_url('files/'); ?>css/style.css">

     <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}

      .rd-navbar-classic.rd-navbar-static .rd-navbar-aside-outer {
          background: #B41F15 !important;
      }
      .rd-navbar-classic.rd-navbar-static .rd-navbar-aside {
    padding: 3px 0 !important;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #ffffff;
}
.owl-carousel-center .owl-item {
    filter: none !important;
    -webkit-filter: none !important;
    }
.rd-navbar-static .rd-nav-link {
    position: relative;
    display: inline-block;
    font-family: 'EB Garamond', serif !important;
    color: #3D4390 !important;
    font-size: 16px;
    line-height: 1.2;
    transition: .25s;
    letter-spacing: 0.05em;
    font-weight: 600;
}
body {
    font-family: 'EB Garamond', serif !important;
    }
    .quote-corporate{
          border-bottom: 1px solid white !important;

    }
    @media (min-width: 1200px){
.section-lg {
    padding: 43px 0 !important;
}
}
/*.quote-corporate .quote-image{
left: 400px;
  margin-bottom: 185px;
}*/
.owl-dots {
    text-align: center;
    margin-top: -51px;
}
.owl-prev, .owl-next {
    top: 42% !important;
}
.owl-carousel-center .owl-prev, .owl-carousel-center .owl-next {
    background: #BA2317 !important;
}
@media (min-width: 1200px){
.container + .container {
    margin-top: -9px;
}
}
   </style>
   </head>