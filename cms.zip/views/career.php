
    <?php include_once('head.php') ?>
   
  
  <body>
   
    <div class="preloader">
      <div class="preloader-body"> 
        <div class="cssload-jumping"><span></span><span></span><span></span><span></span><span></span></div>
      </div>
    </div>
    <!-- <a class="banner banner-top" href="https://www.templatemonster.com/website-templates/monstroid2.html" target="_blank"><img src="<?php echo base_url('files/'); ?>images/monstroid.jpg" alt="" height="0"></a> -->
    <div class="page">
      <!-- Page Header-->
 <?php include_once('header.php') ?>
      <!-- Swiper-->
     <section class="section-page-title" style="background-image: url(<?php echo base_url('files/'); ?>images/page-title-3-1920x305.jpg); background-size: cover;">
        <div class="container">
        <div class="row">
            <div class="col-sm-12">
            <center>  <h4 style="color:white">Find Your Dream Job</h4> </center><br>
            </div>
            <div class="col-sm-5">
              <div class="form-group">
                <input type="" name="" class="form-control" placeholder="keywords" style="border-radius: 0px">
              </div>
            </div>
            <div class="col-sm-5">
               <div class="form-group">
                <input type="" name="" class="form-control" placeholder="Location" style="border-radius: 0px">
              </div>
            </div>
            <div class="col-sm-2">
              <button type="button" class="btn btn-sm btn-primary" style="color: white;background-color: #730300;    height: 48px;border: 1px solid #730300;border-radius: 0px;">Search</button>
            </div>
          </div>
        </div>
      </section>
   
<section class="section section-lg bg-default">
        <div class="container">
          <?php  foreach ($job_post as $key => $value) {
              # code...
            ?>
          <div class="row" style="    box-shadow: gainsboro 1px 0px 6px 0px;padding: 15px;">
               <div class="col-md-2"><img src="https://i.imgsafe.org/dd/dd7067cebf.png" alt="" width="150" height="100">
                </div>
                <div class="col-md-8">
               <h4><?php  echo $value['title']; ?></h4>
                  <p class="text-gray-800"><?php  echo $value['skill']; ?></p>
                  <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#exampleModal<?php echo $value['id']; ?>" style="float: right;background-color: #920000;color: white;border:1px solid #920000">Apply Job</button>
                </div>
                  <div class="col-md-2">
                    <ul class="">
                      <li><i class="fa fa-calendar" aria-hidden="true"></i> &nbsp; <?php  echo $value['experiance']; ?> years</li>
                      <li><i class="fa fa-map-marker" aria-hidden="true"></i> &nbsp; <?php  echo $value['location']; ?></li>
                      <li><i class="fa fa-money" aria-hidden="true"></i> &nbsp; <?php  echo $value['sallary']; ?></li>
                      
                    </ul>
                </div>
          </div>

            <div class="modal fade" id="exampleModal<?php echo $value['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="
    margin-top: 20%;
    
">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Apply Now</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="<?php echo base_url('home/apply_now'); ?>" method="post" enctype="multipart/form-data">
         <div class="form-group">
    <label for="exampleInputEmail1">First Name</label>
    <input type="text" class="form-control" name="name" aria-describedby="emailHelp" placeholder="Enter First Name">
    <input type="hidden" class="form-control" name="post_id" value="<?php echo $value['id']; ?>">
  </div>
   <div class="form-group">
    <label for="exampleInputEmail1">Last Name</label>
    <input type="text" class="form-control" name="lname" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Last Name">
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
   
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Mobile Number</label>
    <input type="number" class="form-control" name="mobile" id="exampleInputPassword1" placeholder="Enter Mobile Number">
  </div>
   <div class="form-group">
    <label for="exampleInputEmail1">Resume</label>
    <input type="file" class="form-control" name="photo" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
    
  </div>
  
  

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div></form>
    </div>
  </div>
</div>
            <?php  } ?>
           
        </div>
      </section>
      
    
      <?php include_once('footer.php') ?>
     
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="<?php echo base_url('files/'); ?>js/core.min.js"></script>
    <script src="<?php echo base_url('files/'); ?>js/script.js"></script>
    

  </body>
</html>