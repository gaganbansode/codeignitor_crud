
       <?php  include 'head.php'; ?>
   
  
  <body>
   
    <div class="preloader">
      <div class="preloader-body"> 
        <div class="cssload-jumping">
  <img src="https://i.imgsafe.org/df/dffa2bb342.jpeg">
          <span></span><span></span><span></span><span></span><span></span></div>
      </div>
    </div><!-- <a class="banner banner-top" href="https://www.templatemonster.com/website-templates/monstroid2.html" target="_blank"><img src="<?php echo base_url('files/'); ?>images/monstroid.jpg" alt="" height="0"></a> -->
    <div class="page">
      <!-- Page Header-->
 
       <?php  include 'header.php'; ?>
      <!-- Swiper-->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <?php 
    $i=1;
     foreach ($slider as $key => $value) {
              # code...
            ?>
    <li data-target="#carouselExampleIndicators" data-slide-to="<?php  echo $i++; ?>"></li>
   
     <?php  } ?>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
     <a href="<?php  echo $slider[0]['link']; ?>" target="_blank">  <img class="d-block w-100" src="<?php echo base_url('uploads/'.$slider[0]['photo']); ?>" alt="First slide"></a>
    </div>
    <?php  foreach ($slider as $key => $value) {
              # code...
            ?>
    <div class="carousel-item">
     <a href="<?php  echo $value['link']; ?>" target="_blank"> <img class="d-block w-100" src="<?php echo base_url('uploads/'.$value['photo']); ?>" alt="Second slide"></a>
    </div>
     <?php  } ?>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
    
  <section class="section section-lg bg-default">
        <div class="container">
          <div class="row row-50">
            <div class="col-lg-6">
              <div class="block-xs">
                <h4 class="heading-decorate">WHY OXIINC GROUP</h4>
                <p class="big text-gray-800">Thanks to our clients’ regular reviews, testimonials, and comments we are able to improve our salon.</p>
                <p>Unlike other salons, we prefer to maintain a constant connection with our customers and receive feedback on every service, whether it’s a simple haircut or complex wedding makeup. If you’ve already visited Glory, feel free to contact us and send your testimonial.</p>
              </div>
            </div>
            <div class="col-lg-6">
              <!-- Owl Carousel-->
              <div class="owl-carousel carousel-corporate" data-items="1" data-dots="true" data-nav="false" data-stage-padding="10px" data-loop="true" data-autoplay="true" data-margin="25px" data-mouse-drag="false">
                <div class="quote-corporate">
                  <div class="quote-header">
                    <h4>1. Qualified IT Professionals</h4>
                   
                  </div>
                  <div class="quote-body">
                    <div class="quote-text">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                      consequat. </p>
                    </div>
                  
                  </div>
                  <div class="quote-image"><img src="<?php echo base_url('files/'); ?>images/1n.png" alt="" width="90" height="90"/>
                  </div>
                </div>
                <div class="quote-corporate">
                  <div class="quote-header">
                    <h4>2. Clients Worldwide</h4>
                  
                  </div>
                  <div class="quote-body">
                    <div class="quote-text">
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                      consequat. </p>
                    </div>
                  
                  </div>
                  <div class="quote-image"><img src="<?php echo base_url('files/'); ?>images/2.png" alt="" width="90" height="90"/>
                  </div>
                </div>
                <div class="quote-corporate">
                  <div class="quote-header">
                    <h4>3. Pan India Presence</h4>
                  <!--   <p class="big">Client</p> -->
                  </div>
                  <div class="quote-body">
                    <div class="quote-text">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                      consequat. </p>
                    </div>
                  
                  </div>
                  <div class="quote-image"><img src="<?php echo base_url('files/'); ?>images/5.png" alt="" width="90" height="90"/>
                  </div>
                </div>
                  <div class="quote-corporate">
                  <div class="quote-header">
                    <h4>4. Focused on Startups & New Technologies</h4>
                   <!--  <p class="big">Client</p> -->
                  </div>
                  <div class="quote-body">
                    <div class="quote-text">
                       <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                      consequat. </p>
                    </div>
                  
                  </div>
                  <div class="quote-image"><img src="<?php echo base_url('files/'); ?>images/7.png" alt="" width="90" height="90"/>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    

      <section class="section section-lg bg-default" style="background-color: aliceblue;padding: 48px 0 !important;">

        <div class="container">

         <center> <h2>OUR SERVICES</h2> </center>
        <center>   <div class="divider-lg"></div></center>
       
          <div class="row row-50 align-items-lg-center justify-content-xl-between">
           
            <div class="col-lg-12">
              <div class="box-images-classic">
                <div class="row row-30">
                  <?php  foreach ($services as $key => $value) {
              # code...
            ?>
                  <div class="col-3">
                    <div class="box-image-item avinash" data-parallax-scroll="{&quot;y&quot;: 0, &quot;x&quot;: -20,  &quot;smoothness&quot;: 30 }"><img src="<?php echo base_url('uploads/'.$value['photo']); ?>" alt="?php  echo $value['title']; ?>" style="height: 300px;width: 100%" />
                       <div class="overlay">
                        <div class="text"><?php  echo $value['title']; ?></div>
                      </div>
                    </div>
                  </div>
                  <?php  } ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section section-md bg-default text-center" style="padding-bottom: 1px !important;">
        <div class="container">
          <h2>Our Brands</h2>
          <div class="divider-lg"></div>
         
        </div>
        <div class="container">
          <div class="row row-20">
            <div class="col-12">
              <!-- Owl Carousel-->
              <div class="owl-carousel owl-carousel-center" data-items="1" data-md-items="3" data-xl-items="5" data-dots="false" data-nav="true" data-stage-padding="0" data-loop="true" data-margin="0" data-mouse-drag="false" data-center="true" data-autoplay="true">
               <?php  foreach ($brand as $key => $value) {
              # code...
            ?>
                <div class="team-minimal">
                  <figure>
                    <a href="<?php  echo $value['link']; ?>" target="_blank"><img src="<?php echo base_url('uploads/'.$value['photo']); ?>" alt="" width="370" height="370"></a>

                  </figure>
              
                </div>
 <?php  } ?>
                
               
                 
              </div>
            </div>
            
          </div>
        </div>
      </section>

    <!--   <footer class="section bg-default section-xs-type-1 footer-minimal" style="background-color: #3C468C;">
        <div class="container">
          <div class="row row-30 align-items-lg-center justify-content-lg-between">
            <div class="col-lg-2">
              <div class="footer-brand"><a href="index.html"><img src="<?php echo base_url('files/'); ?>images/logo.png" alt="" width="257" height="84"/></a></div>
            </div>
            <div class="col-lg-10">
              <div class="footer-nav">
                <ul class="rd-navbar-nav">
                  <li class="rd-nav-item active"><a class="rd-nav-link" href="#">Home</a></li>
                  <li class="rd-nav-item"><a class="rd-nav-link" href="#">About</a></li>
                  <li class="rd-nav-item"><a class="rd-nav-link" href="#">Typography</a></li>
                  <li class="rd-nav-item"><a class="rd-nav-link" href="#">Contacts</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer> -->
      <?php include_once('footer.php') ?>
     
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="<?php echo base_url('files/'); ?>js/core.min.js"></script>
    <script src="<?php echo base_url('files/'); ?>js/script.js"></script>
  </body>
</html>