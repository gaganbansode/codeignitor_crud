<!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Oxiine Group</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/animate.css">
    
    <link rel="stylesheet" type="text/css" href="css/style.css" />

    <style>
.main-banner{
    width: 100%;
     } 
     /* sticky menu */
.navbar-brand {
  padding: 0px;
  height: 70px;
}
.navbar-brand>img {
  height: 100%;
  padding: 15px;
  width: auto;
}
.example2 .navbar-brand>img {
  padding: 7px 15px;
}
.navbar{
    margin-bottom: 0px;
}
.navbar-default{
    border: none;
    font-size: 20px;
    font-family: Roboto;
}

h1,p{
font-family: Roboto;
}
 /* Set black background color, white text and some padding */
      footer {
        background-color: #05205F;;
        color: white;
         }
h1{
     font-weight: 800;
      font-size: 60px;
  }
/* mobile */   
@media only screen and (max-width: 600px){
  h1{
    font-size: 30px;
    }
  }
@media only screen and (max-width: 1366px){
    .pc{
      margin-top: -40px;
    }
}
@media  (min-width: 768px) and (max-width:768px){
    .jack{
      padding-left: 100px;
    }
}
    </style>
</head>
<body>
    

      
      
<?php include_once('header.php') ?>

   
  
  <section>
  <div class="container">
    <center><h1>PORTFOLIO</h1></center><br>
    <div class="row jack">
    <div class="col-sm-10 col-md-2 col-xl-10"></div>
        <div class="col-sm-10 col-md-10 col-xl-10 wow fadeInRight" style="background-color: #f2dede;">
            <figure style="text-align: center; padding-bottom: 15px;">
              <img src="img/microsoft.png" width="200px" height="200px" class="img-rounded  " style="    margin-bottom: 15px;">
              
              <h1 class="pc">Microsoft Technologies</h1>
              <p>The Management Team at Oxiinc Group has the combined experience of pioneering Digital Business in the country. The professionals involved in establishing Digital Business companies and making them successful have turned entrepreneurs to bring forth the best of Opportunity and Products through Oxiinc.</p>
            </figure>
          </div>
        </div><br>
        <div class="row jack">
        <div class="col-sm-10 col-md-10 col-xl-10 wow fadeInLeft" style="background-color: #fcf8e3;">
          <figure style="text-align: center;padding-bottom: 15px;">
              <img src="img/java.png" width="200px" height="200px" class="img-rounded  " style="    margin-bottom: 15px;">
              
              <h1>JAVA Framework</h1>
              <p>The Management Team at Oxiinc Group has the combined experience of pioneering Digital Business in the country. The professionals involved in establishing Digital Business companies and making them successful have turned entrepreneurs to bring forth the best of Opportunity and Products through Oxiinc.</p>
            </figure>
      </div>
        <div class="col-sm-10 col-md-2 col-xl-10"></div>
        </div>
      <br>
      <div class="row jack">
    <div class="col-sm-10 col-md-2 col-xl-10"></div>
        <div class="col-sm-10 col-md-10 col-xl-10 wow fadeInRight" style="background-color: #f2dede;">
            <figure style="text-align: center; padding-bottom: 15px;">
              <img src="img/php.png" width="200px" height="200px" class="img-rounded  " style="    margin-bottom: 15px;">
              
              <h1>PHP Framework</h1>
              <p>The Management Team at Oxiinc Group has the combined experience of pioneering Digital Business in the country. The professionals involved in establishing Digital Business companies and making them successful have turned entrepreneurs to bring forth the best of Opportunity and Products through Oxiinc.</p>
            </figure>
          </div>
        </div><br>
        <div class="row jack">
        <div class="col-sm-10 col-md-10 col-xl-10 wow fadeInLeft" style="background-color: #fcf8e3;">
          <figure style="text-align: center; padding-bottom: 15px;">
              <img src="img/front_end.png" width="200px" height="200px" class="img-rounded  " style="    margin-bottom: 15px;">
              
              <h1>Front-End Technologies</h1>
              <p>The Management Team at Oxiinc Group has the combined experience of pioneering Digital Business in the country. The professionals involved in establishing Digital Business companies and making them successful have turned entrepreneurs to bring forth the best of Opportunity and Products through Oxiinc.</p>
            </figure>
      </div>
        <div class="col-sm-10 col-md-2 col-xl-10"></div>
        </div>
      <br>
  </section>
  <script>
      window.onscroll = function () { myFunction() };

      var header = document.getElementById("navbar2");
      var sticky = header.offsetTop;

      function myFunction() {
        if (window.pageYOffset > sticky) {
          header.classList.add("sticky");
        } else {
          header.classList.remove("sticky");
        }
      }
    </script>

    <!-- footer section start from here -->
  <?php include_once('footer.php') ?>
  <!-- footer section end from here -->
   <button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
  <script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("myBtn").style.display = "block";
  } else {
    document.getElementById("myBtn").style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
<script>
      window.onscroll = function () { myFunction() };

      var header = document.getElementById("navbar2");
      var sticky = header.offsetTop;

      function myFunction() {
        if (window.pageYOffset > sticky) {
          header.classList.add("sticky");
        } else {
          header.classList.remove("sticky");
        }
      }
    </script>
  <script type="text/javascript" src="js/wow.min.js"></script>
  <script>// WOW Animation 
        new WOW().init();
  </script>
  <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
</body>
</html>