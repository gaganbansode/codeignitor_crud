
   <?php include_once('head.php') ?>
 
  <body style="background-color: #FFDBCA">
   
    <div class="preloader">
      <div class="preloader-body"> 
        <div class="cssload-jumping"><span></span><span></span><span></span><span></span><span></span></div>
      </div>
    </div>
    <div class="page">
      <!-- Page Header-->
    <?php include_once('header.php') ?>
      <section class="section-page-title" style="background-image: url(<?php echo base_url('files/'); ?>images/page-title-3-1920x305.jpg); background-size: cover;">
        <div class="container">
       <!--    <h1 class="page-title">About</h1> -->
        </div>
      </section>
      <!-- <section class="breadcrumbs-custom">
        <div class="container">
          <ul class="breadcrumbs-custom-path">
            <li><a href="index.html">Home</a></li>
            <li class="active">About</li>
          </ul>
        </div>
      </section> -->
      <section class="section section-lg bg-default">
        <div class="container">
          <div class="row row-50 align-items-lg-center justify-content-xl-between">
          
            <div class="col-lg-6">
             <figure style="border: 2px solid red;
    text-align: center;border-radius: 40px; margin-bottom: 10px;">
              <img src="<?php echo base_url('files/'); ?>images/shakti.jpg" width="200px" height="200px" class="img-circle" style="    margin-bottom: 15px; margin-top: 15px;    border-radius: 122px;">
              <figcaption style="text-align: center;"><h4>SHAKTIKUMAR THAKUR</h4></figcaption>
              <figcaption style="text-align: center;">FOUNDER, MANAGING DIRECTOR, CEO</figcaption>
              <h3>Oxiinc Group Of Companies</h3>
              <p>The Management Team at Oxiinc Group has the combined experience of pioneering Digital Business in the country. The professionals involved in establishing Digital Business companies and making them successful have turned entrepreneurs to bring forth the best of Opportunity and Products through Oxiinc.</p><br><br>
            </figure>
            </div>
             <div class="col-lg-6">
              <figure style="border: 2px solid red;
    text-align: center;border-radius: 40px;">
              <img src="<?php echo base_url('files/'); ?>images/prince.jpg" width="200px" height="200px" class="img-circle" style="    margin-bottom: 15px; margin-top: 15px;    border-radius: 122px;">
              <figcaption style="text-align: center;"><h4>PRINCE KUMAR</h4></figcaption>
              <figcaption style="text-align: center;">DIRECTOR, COO</figcaption>
              <h3>Oxiinc Group Of Companies</h3>
              <p>An outstanding sales, marketing, and operations professional, and a renowned motivator, Prince Kumar played key roles in various Traning companies. Through his resilient leadership skills, he is continuously leading Oxiinc Group in bringing new practices on board and is training thousands of people every Month through his specially crafted training programmes for Information Technology / Digital selling / internet Marketing professionals.</p>
            </figure>
             </div>
          </div>
        </div>
      </section>
    
   
    
       <?php include_once('footer.php') ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="<?php echo base_url('files/'); ?>js/core.min.js"></script>
    <script src="<?php echo base_url('files/'); ?>js/script.js"></script>
  </body>
</html>